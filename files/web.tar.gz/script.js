new Vue({
  el: '#app',
  data() {
    return {
      bg: 'bio' };

  } });